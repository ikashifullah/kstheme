#Simple Upload Widget

Widget that allows for files to be uploaded. Returns the uploaded media as an image path

##Usage

Once the plugin is installed, visit the Widgets section of your wordpress install and add the widget to a widgetized area. Upload files using the widget and visit the widgetized area to view the image.

The widget will display media in the image tag.
