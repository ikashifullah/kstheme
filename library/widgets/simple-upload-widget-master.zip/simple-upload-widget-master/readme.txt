=== Simple Upload Widget ===
Contributors: fuhton
Tags: widget, theme, file, template, appearance, image, upload, simple, single
Tested up to: 3.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Widget that allows for files to be uploaded. Returns the uploaded media as an image

== Description ==

[Available on GitHub](https://github.com/fuhton/simple-upload-widget)

= Usage =

Once the plugin is installed, visit the Widgets section of your wordpress install and add the widget to a widgetized area. Upload files using the widget and visit the widgetized area to view the image.

The widget will display media in the image tag.
