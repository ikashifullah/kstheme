FontAwesome 4.3 Array & Class Names
===================================

Updated on 2 June 2015 and includes an Excel document for editing and sorting

A PHP associative array of FontAwesome Class Names

Usage: Include array.php in any way you wish. Then call the function into a variable:

````$icons = ebor_icons_list();````
  
That's it!

### Thanks To:

[@anjelajholden](https://github.com/angelajholden)
